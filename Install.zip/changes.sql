ALTER TABLE `products` CHANGE `file_path` `file_path` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL;
